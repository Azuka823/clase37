# PROC37-1_4-actividad-maestra1
## Actividad de la maestra 1 para la clase 37 nivel PRO 1-4.
### Nombre en inglés: C36_SpeedRacer_TeacherActivity

Juego de autos multijugador.

Plantilla para agregar la configuración de la base de datos Firebase.

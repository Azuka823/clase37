class Player {
  constructor() {
   
  }

  
}
